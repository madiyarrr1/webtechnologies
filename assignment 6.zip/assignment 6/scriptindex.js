const currentTheme = localStorage.getItem('theme');
const body = document.getElementById('pageBody');
const propertiesSection = document.querySelector('.properties');
const faqPopup = document.getElementById('faqPopup');

function applyTheme(theme) {
    if (theme === 'dark') {
        body.classList.add('bg-dark', 'text-light');
        propertiesSection.classList.remove('light-theme');
        propertiesSection.classList.add('dark-theme');
        faqPopup.classList.remove('light-theme');
        faqPopup.classList.add('dark-theme');
        document.getElementById('theme-toggle').checked = true;
    } else {
        body.classList.remove('bg-dark', 'text-light');
        propertiesSection.classList.remove('dark-theme');
        propertiesSection.classList.add('light-theme');
        faqPopup.classList.remove('dark-theme');
        faqPopup.classList.add('light-theme');
        document.getElementById('theme-toggle').checked = false;
    }
}

function applySavedTheme() {
    const savedTheme = localStorage.getItem('theme') || 'light';
    applyTheme(savedTheme);
}

if (currentTheme) {
    applyTheme(currentTheme);
} else {
    applyTheme('light'); // По умолчанию светлая тема
}

document.getElementById('theme-toggle').addEventListener('change', function() {
    const newTheme = this.checked ? 'dark' : 'light';
    applyTheme(newTheme);
    localStorage.setItem('theme', newTheme);
});

// Показывать pop-up при клике на кнопку FAQ
document.getElementById('faqBtn').addEventListener('click', function() {
    faqPopup.classList.add('show');
});

// Закрыть pop-up при клике на крестик
document.getElementById('closeFaq', 'closeAuth').addEventListener('click', function() {
    faqPopup.classList.remove('show');
});

// Закрыть pop-up при клике вне содержимого
faqPopup.addEventListener('click', function(event) {
    if (event.target === faqPopup) {
        faqPopup.classList.remove('show');
    }
});



// Установка текущей даты и времени
const dateTimeElement = document.getElementById('currentDateTime');
const updateDateTime = () => {
    const now = new Date();
    dateTimeElement.textContent = now.toLocaleString();
};
updateDateTime();
setInterval(updateDateTime, 1000);

// Применение сохранённой темы при загрузке страницы
applySavedTheme();

document.addEventListener('DOMContentLoaded', () => {
    const currentDateTimeElem = document.getElementById('currentDateTime');
    const now = new Date();
    const options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric', hour: '2-digit', minute: '2-digit' };
    currentDateTimeElem.innerText = now.toLocaleDateString('en-US', options);

    // Приветствие
    const hours = now.getHours();
    let greeting = 'Hello';
    if (hours < 12) {
        greeting = 'Good morning';
    } else if (hours < 18) {
        greeting = 'Good afternoon';
    } else {
        greeting = 'Good evening';
    }
    document.getElementById('greeting').innerText = greeting;
});

