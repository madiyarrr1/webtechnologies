const themeToggle = document.getElementById('theme-toggle');
const popupBtn = document.getElementById('popupBtn');
const closePopup = document.getElementById('closePopup');
const myPopup = document.getElementById('myPopup');
const faqBtn = document.getElementById('faqBtn');
const faqPopup = document.getElementById('faqPopup');
const closeFaq = document.getElementById('closeFaq');

// Функция для применения темы
function applyTheme(theme) {
    document.body.classList.remove('day-theme', 'night-theme');
    document.body.classList.add(theme);
    themeToggle.checked = (theme === 'night-theme');
}

// Функция для применения сохранённой темы
function applySavedTheme() {
    const savedTheme = localStorage.getItem('theme') || 'day-theme';
    applyTheme(savedTheme);
}

// Получаем сохранённую тему из localStorage при загрузке страницы
applySavedTheme();

// Событие для переключения темы и сохранения её в localStorage
themeToggle.addEventListener('change', () => {
    const currentTheme = document.body.classList.contains('night-theme') ? 'night-theme' : 'day-theme';
    const newTheme = currentTheme === 'day-theme' ? 'night-theme' : 'day-theme';
    applyTheme(newTheme);
    localStorage.setItem('theme', newTheme); // Сохраняем новую тему
});

// Открытие и закрытие основного pop-up
popupBtn.addEventListener('click', () => {
    myPopup.style.display = 'flex';
    setTimeout(() => {
        myPopup.classList.add('show');
    }, 10);
});

closePopup.addEventListener('click', () => {
    myPopup.classList.remove('show');
    setTimeout(() => {
        myPopup.style.display = 'none';
    }, 500);
});

// Открытие и закрытие FAQ pop-up
faqBtn.addEventListener('click', () => {
    faqPopup.style.display = 'flex';
    setTimeout(() => {
        faqPopup.classList.add('show');
    }, 10);
});

closeFaq.addEventListener('click', () => {
    faqPopup.classList.remove('show');
    setTimeout(() => {
        faqPopup.style.display = 'none';
    }, 500);
});

// Закрытие pop-up при клике вне его содержимого
window.addEventListener('click', (event) => {
    if (event.target === myPopup) {
        myPopup.classList.remove('show');
        setTimeout(() => {
            myPopup.style.display = 'none';
        }, 500);
    }
    if (event.target === faqPopup) {
        faqPopup.classList.remove('show');
        setTimeout(() => {
            faqPopup.style.display = 'none';
        }, 500);
    }
});

// Функция для отправки формы с воспроизведением звука
function submitForm() {
    const name = document.getElementById('name').value;
    const email = document.getElementById('email').value;
    const message = document.getElementById('message').value;
    if (name && email && message) {
        const sound = document.getElementById('submitSound');
        sound.play();
        alert("Message sent!");
        document.getElementById('name').value = '';
        document.getElementById('email').value = '';
        document.getElementById('message').value = '';
    } else {
        alert("Please, fill the fields!");
    }
}


